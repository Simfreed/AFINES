// Cytosim was created by Francois Nedelec. Copyright 2007-2017 EMBL.

#include "exceptions.h"


/// This is used to align text in the error messages
const char PREF[] = "        | ";

