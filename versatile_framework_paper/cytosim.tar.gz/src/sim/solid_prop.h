// Cytosim was created by Francois Nedelec. Copyright 2007-2017 EMBL.

#ifndef SOLID_PROP_H
#define SOLID_PROP_H


#include "bead_prop.h"

/// SolidProp is an alias to BeadProp
typedef BeadProp SolidProp;


#endif

