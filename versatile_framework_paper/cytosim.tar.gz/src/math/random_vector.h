// Cytosim was created by Francois Nedelec. Copyright 2007-2017 EMBL.

#ifndef RANDOM_VECTOR_H
#define RANDOM_VECTOR_H


/**
 This file is obsolete:
 functions to generate random vectors are members of class Vector
 */


#endif

