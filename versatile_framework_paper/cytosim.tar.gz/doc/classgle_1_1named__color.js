var classgle_1_1named__color =
[
    [ "hex", "classgle_1_1named__color.html#abcbe938d278e91ab495fa13736d97812", null ],
    [ "name", "classgle_1_1named__color.html#a5f1de76dd5d451949e12c0fbc966ca70", null ]
];