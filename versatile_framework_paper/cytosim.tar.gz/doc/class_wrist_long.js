var class_wrist_long =
[
    [ "WristLong", "class_wrist_long.html#a054a305ac8831db3477c750fb8894404", null ],
    [ "~WristLong", "class_wrist_long.html#ab044b2ca1d7fd8b33fb21dc9614a5108", null ],
    [ "force", "class_wrist_long.html#a378afe5078d05f2f29a5a4069c3cbb30", null ],
    [ "posSide", "class_wrist_long.html#a59431e51dcb7f0c90fe0387f55961fd6", null ],
    [ "setInteractions", "class_wrist_long.html#a0dd83d6251bd19be48463585a3a2d109", null ]
];