var group___slider_par =
[
    [ "mobility", "group___slider_par.html#gae91a2e52b5b7d16ab5d956fcfedadfdb", null ],
    [ "stiffness", "group___slider_par.html#ga575ccdd0e4c30d7c82343fe313533356", null ]
];