var namespacegle =
[
    [ "named_color", "classgle_1_1named__color.html", "classgle_1_1named__color" ]
];