var class_modulo =
[
    [ "Modulo", "class_modulo.html#a4c441f65ac0b91da7a623ead09a72420", null ],
    [ "~Modulo", "class_modulo.html#ac24c6c781735654d10767e138d8f8635", null ],
    [ "fold", "class_modulo.html#a5bacc42b55070c1dd1373418862b59e7", null ],
    [ "fold", "class_modulo.html#a3a0773d11ec28e4a3cdcc6bb03517b57", null ],
    [ "foldOffset", "class_modulo.html#afdfdf3a56b5bec55993e789cec5b169d", null ],
    [ "isPeriodic", "class_modulo.html#a64cd7dae3410d72658c230bf73b95a74", null ],
    [ "period", "class_modulo.html#af5eeeb7509d1124d19c3fff84b3aa820", null ]
];