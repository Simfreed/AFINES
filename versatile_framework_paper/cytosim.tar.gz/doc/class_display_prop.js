var class_display_prop =
[
    [ "DisplayProp", "class_display_prop.html#a6d36fc7e4402e6d586e9b35ea9079670", null ],
    [ "~DisplayProp", "class_display_prop.html#aa8309cdf7cb68a39f7b13c328ac43c6c", null ],
    [ "clear", "class_display_prop.html#ac8bb3912a3ce86b15842e79d0b421204", null ],
    [ "clone", "class_display_prop.html#a3b36bd15ea98c7fd6d2666cf8753b03a", null ],
    [ "kind", "class_display_prop.html#ad728d546106264430db39b791974f8b9", null ],
    [ "read", "class_display_prop.html#a79302f6d5ed23c67123fb65933b76990", null ],
    [ "write_data", "class_display_prop.html#af5cebd033dab3b02404f31f88a458c68", null ],
    [ "back_color", "group___display_par.html#ga1505730fd7943734e471302fd3acf395", null ],
    [ "couple_select", "group___display_par.html#ga8b7a02be1ffb449cc9acf5b246e868d2", null ],
    [ "field_max", "group___display_par.html#gad9cb26fdb4e34cd219f49f8a70cf7238", null ],
    [ "field_number", "group___display_par.html#ga32c929272c8e257848283b03ebc5d45a", null ],
    [ "fold", "group___display_par.html#ga096c947d6c9ab2463d72b87d75b6fa63", null ],
    [ "front_color", "group___display_par.html#ga9bb5ada3915acd31ee6bebf0c3dca81e", null ],
    [ "inner_color", "group___display_par.html#ga9f2fc6d026be5dfa7961ffe8bb8b322e", null ],
    [ "line_width", "group___display_par.html#ga48d40bf515203bbae1a8ab9cd85e5839", null ],
    [ "point_size", "group___display_par.html#ga61cfc3f3a601ce804d4e323d52e4cc56", null ],
    [ "point_value", "group___display_par.html#ga7761be0debe30bbf55b7ac64e7c2ebec", null ],
    [ "single_select", "group___display_par.html#ga2ffafc6555a9a7be8cd01355fe4fb258", null ],
    [ "tiled", "group___display_par.html#ga932b532ba70935890cbd374f54b01659", null ]
];