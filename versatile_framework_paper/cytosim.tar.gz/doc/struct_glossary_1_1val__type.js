var struct_glossary_1_1val__type =
[
    [ "val_type", "struct_glossary_1_1val__type.html#a810be2438d14888e8675f173bcafe877", null ],
    [ "val_type", "struct_glossary_1_1val__type.html#aed686df277637f961aa49bdb3143d7c9", null ],
    [ "cnt", "struct_glossary_1_1val__type.html#a18d252e3203361862b20995f46601ccd", null ],
    [ "str", "struct_glossary_1_1val__type.html#a5d55e2558544e2ad2ea0b54f8e3d41fc", null ]
];