var group___object_group =
[
    [ "Couple and Derived Activities", "group___couple_group.html", "group___couple_group" ],
    [ "Fiber and Derived Activities", "group___fiber_group.html", "group___fiber_group" ],
    [ "Hand and Derived Activities", "group___hand_group.html", "group___hand_group" ],
    [ "Single and Derived Activities", "group___single_group.html", "group___single_group" ],
    [ "Space and Geometry", "group___space_group.html", "group___space_group" ]
];