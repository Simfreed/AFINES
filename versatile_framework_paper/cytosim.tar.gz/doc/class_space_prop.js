var class_space_prop =
[
    [ "SpaceProp", "class_space_prop.html#afb93d875a310b79706dda1aad3f133b0", null ],
    [ "~SpaceProp", "class_space_prop.html#a032c1b0a6dc0ff2d71782cfd897beb08", null ],
    [ "clear", "class_space_prop.html#ac8bb3912a3ce86b15842e79d0b421204", null ],
    [ "clone", "class_space_prop.html#a3b36bd15ea98c7fd6d2666cf8753b03a", null ],
    [ "complete", "class_space_prop.html#a81730c4e27d52b8e5c9834a869c15a3a", null ],
    [ "kind", "class_space_prop.html#ad728d546106264430db39b791974f8b9", null ],
    [ "newSpace", "class_space_prop.html#ac617ee8a6b0fe59ac6bd75025ca54f70", null ],
    [ "read", "class_space_prop.html#a79302f6d5ed23c67123fb65933b76990", null ],
    [ "write_data", "class_space_prop.html#af5cebd033dab3b02404f31f88a458c68", null ],
    [ "Space", "class_space_prop.html#a2129e6c0ac73536a2ac4f681dae16947", null ],
    [ "dimensions", "group___space_par.html#ga36328be1c0c17e26aa79373bff9d4b4b", null ],
    [ "disp", "class_space_prop.html#ac4f1760a084456b9793a3528afa6787f", null ],
    [ "display", "group___space_par.html#ga752a5eb77ec7c529726fc6c1c88f0331", null ],
    [ "file", "class_space_prop.html#aefc35c7944eed319c89bc1b399f0eb67", null ],
    [ "geometry", "group___space_par.html#ga04c49d6dd600c55c8ff2759aa9339146", null ],
    [ "shape", "group___space_par.html#ga844dd8511b288de0d8d8043b17d14102", null ],
    [ "spec", "class_space_prop.html#a863cf41680592b4f9e24a6ffcc729672", null ]
];