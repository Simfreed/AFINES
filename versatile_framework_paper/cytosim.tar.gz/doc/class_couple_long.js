var class_couple_long =
[
    [ "CoupleLong", "class_couple_long.html#a6795102055e93840bdb23ef19d30ccb7", null ],
    [ "~CoupleLong", "class_couple_long.html#aed439cbcbeff685318a9916eff48e8ac", null ],
    [ "force1", "class_couple_long.html#aa66a433b795206d4c7d5ef7ab15184e6", null ],
    [ "posSide", "class_couple_long.html#a59431e51dcb7f0c90fe0387f55961fd6", null ],
    [ "setInteractions", "class_couple_long.html#a0dd83d6251bd19be48463585a3a2d109", null ]
];