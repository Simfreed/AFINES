var class_interface =
[
    [ "Interface", "class_interface.html#a2d89f69482e3083edf18fc056d915b05", null ],
    [ "~Interface", "class_interface.html#a8d07a756bb96ccfc79568730847385b4", null ],
    [ "change_display", "class_interface.html#a8d1c9c68b6ab6b4fbf4fba466f8238b6", null ],
    [ "execute_change", "class_interface.html#a014ec99ae7e8eac617780e944829c26f", null ],
    [ "execute_change", "class_interface.html#a9953e76adf5649fcf638940562b83d76", null ],
    [ "execute_cut", "class_interface.html#a957f983f3751b0e0d9d6913b445db21f", null ],
    [ "execute_delete", "class_interface.html#af4b349a1c19654f293cd8b5e4e8b885a", null ],
    [ "execute_mark", "class_interface.html#ad0a328353fab4ff35c5004cd434bf189", null ],
    [ "execute_new", "class_interface.html#a793fde5db3608b50a7c8ae6ea2ce2f2a", null ],
    [ "execute_new", "class_interface.html#a154cad82a8537a206c99e89c7fbc994e", null ],
    [ "execute_read", "class_interface.html#ab919393b6f9406f7aeb92cb873bc8fe5", null ],
    [ "execute_run", "class_interface.html#a6f1982d7d63336880031b2fda644d202", null ],
    [ "execute_set", "class_interface.html#acf98b7adc0241e3cd5180bd3e9498bef", null ],
    [ "execute_write", "class_interface.html#a6beb25f04de0e403d5819174c403fd2a", null ],
    [ "hold", "class_interface.html#a0bc3310d1754fcb97f971386abc3affc", null ],
    [ "parse", "class_interface.html#a55cf4dcd6a5319f314ab93d4cf7bffe1", null ],
    [ "simul", "class_interface.html#a463e08d31ad9a7921e595e35a74538cd", null ]
];