var group___bridge_par =
[
    [ "specificity", "group___bridge_par.html#gacb77482944e0ea93e1f035b45259c0f1", null ],
    [ "trans_activated", "group___bridge_par.html#ga0f71a11381bd4134995635f5fd72a5de", null ]
];