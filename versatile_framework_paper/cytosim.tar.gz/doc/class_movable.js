var class_movable =
[
    [ "Movable", "class_movable.html#a7d9ebbfbfda8a68bdc7ef1a351d59d44", null ],
    [ "~Movable", "class_movable.html#a47c5d2baa4f76af69abc3adc250f145a", null ],
    [ "foldPosition", "class_movable.html#a0dc85c31e8ebee9394d5cd0186a850ae", null ],
    [ "position", "class_movable.html#a40db8b326b538f55cdd0d2e8dcbbafc5", null ],
    [ "rotatable", "class_movable.html#a2d8bee2ee132f8a7bd27b27205a713f3", null ],
    [ "rotate", "class_movable.html#ae510c8aa4a5a7a9f4d039afbdb4fa03a", null ],
    [ "rotateP", "class_movable.html#a160866e81d483813cdbfa08ca89d0650", null ],
    [ "setPosition", "class_movable.html#a40e0ba82b18c44a14db425a7abc21688", null ],
    [ "translatable", "class_movable.html#aef5c0486f85f90b9a879fdb6058b9ae7", null ],
    [ "translate", "class_movable.html#a1dba38e58fd08f3f70d4a521cd904577", null ]
];