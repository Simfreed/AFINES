var modules =
[
    [ "List of objects", "group___object_group.html", "group___object_group" ],
    [ "How to compile cytosim", "group___compile.html", "group___compile" ],
    [ "Display Parameters", "group___display_parameters.html", "group___display_parameters" ],
    [ "How to create objects", "group___new_object.html", "group___new_object" ],
    [ "All object parameters", "group___parameters.html", "group___parameters" ],
    [ "All Object Properties", "group___properties.html", "group___properties" ]
];