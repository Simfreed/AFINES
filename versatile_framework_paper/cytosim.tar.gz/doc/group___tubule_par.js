var group___tubule_par =
[
    [ "dynamic_model", "group___tubule_par.html#gaeb357979b0b317f066eac199e3ff8818", null ],
    [ "fate", "group___tubule_par.html#ga4fe6d0e9afaa4a6a139db8f72ed960e2", null ],
    [ "growing_force", "group___tubule_par.html#ga7e5c1844454dec06aeb6be88785367a2", null ],
    [ "min_length", "group___tubule_par.html#ga1cfafcb5a4f95cab8630811ed1234a84", null ]
];