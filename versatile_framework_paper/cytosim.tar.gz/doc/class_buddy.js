var class_buddy =
[
    [ "Buddy", "class_buddy.html#a1c5697c1337ad5a6d36877cc41d4c945", null ],
    [ "~Buddy", "class_buddy.html#a3529cf3aebe5d189e9f63b127648b4b4", null ],
    [ "buddy", "class_buddy.html#a6775be3b7e87bbf51e586330bc586f3b", null ],
    [ "buddy", "class_buddy.html#a876bb0920963e3ba94ecd3e27dd7e4d7", null ],
    [ "goodbye", "class_buddy.html#a9b1f135b52b0820f4677f32c8c2f0962", null ],
    [ "hello", "class_buddy.html#aed849b96817f065dc98ede8d21df999c", null ]
];