var class_motor_prop =
[
    [ "MotorProp", "class_motor_prop.html#a424c9cf931b28fd77fea73c435ee4af3", null ],
    [ "~MotorProp", "class_motor_prop.html#a5710a468df825e9a34c6a566826a0898", null ],
    [ "checkStiffness", "class_motor_prop.html#aa3b8851105613c806215cfa8c65f19b2", null ],
    [ "clear", "class_motor_prop.html#ac8bb3912a3ce86b15842e79d0b421204", null ],
    [ "clone", "class_motor_prop.html#a3b36bd15ea98c7fd6d2666cf8753b03a", null ],
    [ "complete", "class_motor_prop.html#a81730c4e27d52b8e5c9834a869c15a3a", null ],
    [ "newHand", "class_motor_prop.html#a0471036dec7a9456502a45463683c535", null ],
    [ "read", "class_motor_prop.html#a79302f6d5ed23c67123fb65933b76990", null ],
    [ "write_data", "class_motor_prop.html#af5cebd033dab3b02404f31f88a458c68", null ],
    [ "Motor", "class_motor_prop.html#a2abea0a22831274b2894ed2675e909b4", null ],
    [ "limit_speed", "group___motor_par.html#ga094300e05909448478c30cb6511a7429", null ],
    [ "max_dabs", "class_motor_prop.html#ab98cbe3640fb1749d630620b7b5672d0", null ],
    [ "max_speed", "group___motor_par.html#ga7f0ac9a26c226c47f3fb71ddfd95222a", null ],
    [ "min_dabs", "class_motor_prop.html#a272415f2e626150e48ca6c5782c4f02e", null ],
    [ "stall_force", "group___motor_par.html#ga22d593fb145923c1d6b08bec61ef807e", null ]
];