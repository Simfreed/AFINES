var group___play_par =
[
    [ "delay", "group___play_par.html#ga40df728951e877187328a971765d7b18", null ],
    [ "dir", "group___play_par.html#ga851cf68c8f607573c1a5e987784c83f6", null ],
    [ "frame", "group___play_par.html#gad30f972f2e6e3e5ecab0dee38ae6cdb8", null ],
    [ "image_dir", "group___play_par.html#ga250641a2356b8a6b07dfb25d40a7a6ba", null ],
    [ "image_format", "group___play_par.html#ga5550f009d9bca93c590f790fc4372089", null ],
    [ "loop", "group___play_par.html#gac4948d3f194cb02e216c672e03cf9eb6", null ],
    [ "magic_key", "group___play_par.html#ga51ef5d8d8a1c12905308ed795ea3f847", null ],
    [ "period", "group___play_par.html#ga528ce5558d238708bc2cb7e5a71ad961", null ],
    [ "report", "group___play_par.html#gaf823407284604c3d64bc7306c0e6e010", null ],
    [ "style", "group___play_par.html#ga4d68f144910566d3cc85c6ebcc173e05", null ]
];