var group___cutter_par =
[
    [ "cutting_rate", "group___cutter_par.html#ga178d4b14f7fc5926f70483d0bf17f43c", null ],
    [ "new_end_state", "group___cutter_par.html#ga9eaa22267a99ade37055d46b57fb78be", null ]
];