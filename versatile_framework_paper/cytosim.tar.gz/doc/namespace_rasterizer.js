var namespace_rasterizer =
[
    [ "Vertex", "struct_rasterizer_1_1_vertex.html", "struct_rasterizer_1_1_vertex" ]
];