var group___display_parameters =
[
    [ "Display parameters: Graphics", "group__gl_app_par.html", "group__gl_app_par" ],
    [ "Display Parameters: View", "group___view_par.html", "group___view_par" ],
    [ "Display parameters: World", "group___display_par.html", "group___display_par" ],
    [ "Display parameters: Fibers", "group___fiber_disp_par.html", "group___fiber_disp_par" ],
    [ "Parameters of Play", "group___play_par.html", "group___play_par" ],
    [ "Display parameters: Points", "group___point_disp_par.html", "group___point_disp_par" ]
];