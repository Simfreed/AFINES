var group___nucleator_par =
[
    [ "addictive", "group___nucleator_par.html#gae83b2f2c358418058d3018d82d6ef648", null ],
    [ "nucleated_fiber", "group___nucleator_par.html#ga7a081a29e89e0d2496a5335db79cd3d6", null ],
    [ "nucleation_rate", "group___nucleator_par.html#gadd791a97940f9b5eefa2965108543c7c", null ],
    [ "nucleation_spec", "group___nucleator_par.html#gae3ab0ffb0074ea3e4077f4178f342ed8", null ],
    [ "specificity", "group___nucleator_par.html#gacb77482944e0ea93e1f035b45259c0f1", null ],
    [ "track_end", "group___nucleator_par.html#ga122c5ad34a0432b25001238fe6e5356d", null ]
];