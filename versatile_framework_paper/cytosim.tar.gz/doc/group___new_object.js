var group___new_object =
[
    [ "How to create a Bead", "group___new_bead.html", null ],
    [ "Couple and Derived Activities", "group___couple_group.html", "group___couple_group" ],
    [ "Fiber and Derived Activities", "group___fiber_group.html", "group___fiber_group" ],
    [ "How to create a Field", "group___new_field.html", null ],
    [ "Hand and Derived Activities", "group___hand_group.html", "group___hand_group" ],
    [ "How to create an Aster", "group___new_aster.html", null ],
    [ "Single and Derived Activities", "group___single_group.html", "group___single_group" ],
    [ "How to create a Solid", "group___new_solid.html", null ],
    [ "Space and Geometry", "group___space_group.html", "group___space_group" ],
    [ "How to create a Sphere", "group___new_sphere.html", null ]
];