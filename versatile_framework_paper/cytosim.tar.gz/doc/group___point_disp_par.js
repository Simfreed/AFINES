var group___point_disp_par =
[
    [ "color", "group___point_disp_par.html#gae41ad33fd4369b85af12f136dbd0c282", null ],
    [ "coloring", "group___point_disp_par.html#gab58c00f08de7646d2da85e0f6d577209", null ],
    [ "shape", "group___point_disp_par.html#ga9a3e790d202f0388ff6d672add61855a", null ],
    [ "size", "group___point_disp_par.html#ga44f33d458de2fe25f7446d00ad65e651", null ],
    [ "style", "group___point_disp_par.html#ga9de4a1b8589ee213fe24ec0f26213484", null ],
    [ "symbol", "group___point_disp_par.html#gaf7565614b2ea8e3f98b39303ae09ebca", null ],
    [ "symbol_color", "group___point_disp_par.html#ga6ade24b581ce99de3304981960d223fb", null ],
    [ "visible", "group___point_disp_par.html#ga1dc0236b1bb47613cbf3ca7033830321", null ],
    [ "width", "group___point_disp_par.html#ga67add78c9520d756fddff7c6b3116f55", null ]
];