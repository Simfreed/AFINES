#include "filament_ensemble.h"
#include "motor_ensemble.h"
#include "globals.h"

#include <iostream>
#include <fstream> 
#include <iterator>
#include <array>
#include <boost/program_options.hpp>
namespace po = boost::program_options;

template<class T>
ostream& operator<<(ostream& os, const vector<T>& v)
{
    copy(v.begin(), v.end(), ostream_iterator<T>(os, " "));
    return os;
}


//main method
int main(int argc, char* argv[]){
    

    /***********************
     * VARIABLES           *
     **********************/
    
    int myseed;
    
    double xrange, yrange;                                                  //Space
    int xgrid, ygrid;
    double grid_factor; 
    
    int    count, nframes, nmsgs;                                  //Time 
    double t, tinit, tfinal, dt;
    
    double viscosity, temperature;                                          //Environment
    string bnd_cnd;                                         //Allowed values: NONE, PERIODIC, REFLECTIVE

    double actin_length, npolymer, nmonomer;                                // Actin 
    string actin_pos_str;
    
    double link_length, polymer_bending_modulus, link_stretching_stiffness, fene_pct = 0, fracture_force; // Links
    
    double spacer_length, spacer_density, spacer_stiffness, // Passive Mtors (i.e., cross_linkers)
            spacer_v=0, s_kon, s_kend, s_koff, s_stall, s_break, s_bind, s_bend, s_th0; 
    string spacer_pos_str;
    
    string config_file, actin_in, spacer_in;                                                // Input configuration
    
    string   dir,    afile,  pmfile,  lfile, thfile, pefile;                  // Output
    ofstream o_file, file_a, file_s, file_l, file_th, file_pe;
    ios_base::openmode write_mode = ios_base::out;

    bool link_intersect_flag, dead_head_flag, static_cl_flag, quad_off_flag;
    double linkage_prob;                                              
    int dead_head;

    bool restart_actin, restart_spacer;

    //Options allowed only on command line
    po::options_description generic("Generic options");
    generic.add_options()
        ("version, v", "print version string")
        ("help", "produce help message")
        ("config,c", po::value<string>(&config_file)->default_value("config/network.cfg"), "name of a configuration file")
        ;

    //Options allowed in a config file
    po::options_description config("Configuration");
    config.add_options()
        
        ("xrange", po::value<double>(&xrange)->default_value(10), "size of cell in horizontal direction (um)")
        ("yrange", po::value<double>(&yrange)->default_value(10), "size of cell in vertical direction (um)")
        ("grid_factor", po::value<double>(&grid_factor)->default_value(2), "number of grid boxes per um^2")
        
        ("dt", po::value<double>(&dt)->default_value(0.0001), "length of individual timestep in seconds")
        ("tinit", po::value<double>(&tinit)->default_value(0), "time that recording of simulation starts")
        ("tfinal", po::value<double>(&tfinal)->default_value(0.01), "length of simulation in seconds")
        ("nframes", po::value<int>(&nframes)->default_value(1000), "number of times between actin/link/motor positions to are printed to file")
        ("nmsgs", po::value<int>(&nmsgs)->default_value(10000), "number of times simulation progress is printed to stdout")
       
        ("viscosity", po::value<double>(&viscosity)->default_value(0.001), "Dynamic viscosity to determine friction [mg / (um*s)]. At 20 C, is 0.001 for water")
        ("temperature,temp", po::value<double>(&temperature)->default_value(0.004), "Temp in kT [pN-um] that effects magnituded of Brownian component of simulation")
        ("bnd_cnd,bc", po::value<string>(&bnd_cnd)->default_value("PERIODIC"), "boundary conditions")
        
        ("nmonomer", po::value<double>(&nmonomer)->default_value(11), "number of monomers per filament")
        ("npolymer", po::value<double>(&npolymer)->default_value(3), "number of polymers in the network")
        ("actin_length", po::value<double>(&actin_length)->default_value(0.5), "Length of a single actin monomer")
        ("actin_pos_str", po::value<string> (&actin_pos_str)->default_value(""), "Starting positions of actin polymers, commas delimit coordinates; semicolons delimit positions")
        
        ("spacer_density", po::value<double>(&spacer_density)->default_value(0.05), "number of passive motors / um^2")
        ("spacer_pos_str", po::value<string> (&spacer_pos_str)->default_value(""), "Starting positions of crosslinks, commas delimit coordinates; semicolons delimit positions")
        
        ("s_kon", po::value<double>(&s_kon)->default_value(100),"passive motor on rate")
        ("s_koff", po::value<double>(&s_koff)->default_value(20),"passive motor off rate")
        ("s_kend", po::value<double>(&s_kend)->default_value(20),"passive motor off rate at filament end")
        ("spacer_length", po::value<double>(&spacer_length)->default_value(0.150),"passive motor rest length (um) (default: filamin)")
        ("spacer_stiffness", po::value<double>(&spacer_stiffness)->default_value(1),"passive motor spring stiffness (pN/um)")
       
        ("s_stall", po::value<double>(&s_stall)->default_value(0),"force beyond which xlinks don't walk (pN)")
        ("s_break", po::value<double>(&s_break)->default_value(10),"force constant for xlink detachment (related to rupture force F_r, P(detach | F_r) -> 1) (pN)")
        ("s_bind", po::value<double>(&s_bind)->default_value(0.04),"binding energy of xlink (pN-um) (10kT by default)")
        ("s_bend", po::value<double>(&s_bend)->default_value(0.04),"bending modulus of xlink (pN-um^2) (10kT-um by default)")
        ("s_th0", po::value<double>(&s_th0)->default_value(pi/2),"equilibrium angle of xlink")
        

        ("link_length", po::value<double>(&link_length)->default_value(1), "Length of links connecting monomers")
        ("polymer_bending_modulus", po::value<double>(&polymer_bending_modulus)->default_value(0.04), "Bending modulus of a filament")
        ("fracture_force", po::value<double>(&fracture_force)->default_value(100000000), "pN-- filament breaking point")
        ("link_stretching_stiffness,ks", po::value<double>(&link_stretching_stiffness)->default_value(1), "stiffness of link, pN/um")//probably should be about 70000 to correspond to actin
        
        ("actin_in", po::value<string>(&actin_in)->default_value(""), "input actin positions file")
        ("spacer_in", po::value<string>(&spacer_in)->default_value(""), "input crosslinker positions file")
        
        ("restart_actin", po::value<bool>(&restart_actin)->default_value(false), "if true, input actin positions file chosen by default")
        ("restart_spacer", po::value<bool>(&restart_spacer)->default_value(false), "if true, input crosslinker positions file chosen by default")
        
        ("dir", po::value<string>(&dir)->default_value("out/test"), "output directory")
        ("myseed", po::value<int>(&myseed)->default_value(time(NULL)), "Random number generator myseed")
        
        ("link_intersect_flag", po::value<bool>(&link_intersect_flag)->default_value(false), "flag to put a cross link at all filament intersections")
        ("linkage_prob", po::value<double>(&linkage_prob)->default_value(1), "If link_intersect_flag, probability that two filaments that intersect will be linked")

        ("dead_head_flag", po::value<bool>(&dead_head_flag)->default_value(false), "flag to kill head <dead_head> of all motors")
        ("dead_head", po::value<int>(&dead_head)->default_value(0), "index of head to kill")
        
        ("static_cl_flag", po::value<bool>(&static_cl_flag)->default_value(false), "flag to indicate compeletely static xlinks; i.e, no walking, no detachment")
        ("quad_off_flag", po::value<bool>(&quad_off_flag)->default_value(false), "flag to turn off neighbor list updating")
        
        ; 
    
    //Hidden options, will be allowed both on command line and 
    //in config file, but will not be shown to user
    po::options_description hidden("Hidden options");
    hidden.add_options()
        ("input-file", po::value< vector<string> >(), "input file")
        ;

    po::options_description cmdline_options;
    cmdline_options.add(generic).add(config).add(hidden);

    po::options_description config_file_options;
    config_file_options.add(config).add(hidden);

    po::options_description visible("Allowed options");
    visible.add(generic).add(config);
    
    po::positional_options_description p;
    p.add("input-file", -1); ///wha in the world is this doing

    po::variables_map vm;
    store(po::command_line_parser(argc, argv).options(cmdline_options).positional(p).run(), vm);
    notify(vm);

    ifstream ifs(config_file.c_str());
    if (!ifs){
        cout<<"can not open config file: "<<config_file<<"\n";
        return 0;
    }
    else
    {
        store(parse_config_file(ifs, config_file_options), vm);
        notify(vm);
    }
   
    
    if (polymer_bending_modulus < 0){ //This is a flag for using the temperature for the bending modulus
        polymer_bending_modulus = 10*temperature; // 10um * kT
    }

    double actin_density = npolymer*nmonomer/(xrange*yrange);//0.65;
    cout<<"\nDEBUG: actin_density = "<<actin_density; 
    double link_bending_stiffness    = polymer_bending_modulus / link_length;
    
    int n_bw_stdout = max(int(tfinal/(dt*double(nmsgs))),1);
    int n_bw_print  = max(int((tfinal - tinit)/(dt*double(nframes))),1);
    int unprinted_count = int(double(tinit)/dt);

    // To Read positions from input strings in config file
    vector<array<double,3> > actin_position_arrs, spacer_position_arrs;
    if (actin_pos_str.size() > 0)
        actin_position_arrs   = str2arrvec(actin_pos_str, ":", ",");
    if (spacer_pos_str.size() > 0)
        spacer_position_arrs = str2arrvec(spacer_pos_str, ":", ",");
   

    // To Read positions from input files
    vector<vector<double> > actin_pos_vec;
    vector<vector<double> > spacer_pos_vec;
    
    if (restart_actin)
        actin_in = dir + "/restart/in/actins.txt";
    if (restart_spacer)
        spacer_in = dir + "/restart/in/spacers.txt";
    
    if (actin_in.size() > 0)
        actin_pos_vec   = file2vecvec(actin_in, "\t");
    if (spacer_in.size() > 0)
        spacer_pos_vec = file2vecvec(spacer_in, "\t");
    
    set_seed(myseed);
    
    afile  = dir + "/txt_stack/actins.txt";
    lfile  = dir + "/txt_stack/links.txt";
    pmfile = dir + "/txt_stack/spacers.txt";
    thfile = dir + "/data/thermo.txt";
    pefile = dir + "/data/pe.txt";

    if (restart_actin || restart_spacer) write_mode = ios_base::app;

    file_a.open(afile.c_str(), write_mode);
    file_l.open(lfile.c_str(), write_mode);
    file_s.open(pmfile.c_str(), write_mode);
	file_th.open(thfile.c_str(), write_mode);
	file_pe.open(pefile.c_str(), write_mode);


    // DERIVED QUANTITIES :
    if(spacer_density==0 && spacer_pos_vec.size() == 0 && !link_intersect_flag){
        xgrid = 1;
        ygrid = 1;
    }
    else{
        xgrid  = (int) round(grid_factor*xrange);
        ygrid  = (int) round(grid_factor*yrange);
    }

    // Create Network Objects
    cout<<"\nCreating actin network..";
    filament_ensemble * net;
    if (actin_pos_vec.size() == 0){
        net = new filament_ensemble(actin_density, {xrange, yrange}, {xgrid, ygrid}, dt, 
                temperature, actin_length, viscosity, nmonomer, link_length, 
                actin_position_arrs, 
                link_stretching_stiffness, fene_pct, link_bending_stiffness,
                fracture_force, bnd_cnd, myseed); 
    }else{
        net = new filament_ensemble(actin_pos_vec, {xrange, yrange}, {xgrid, ygrid}, dt, 
                temperature, viscosity, link_length, 
                link_stretching_stiffness, fene_pct, link_bending_stiffness,
                fracture_force, bnd_cnd); 
    }
   
    if (link_intersect_flag) spacer_pos_vec = net->link_link_intersections(spacer_length, linkage_prob); 
    if (quad_off_flag) net->turn_quads_off();

    cout<<"Adding passive motors (crosslinkers) ...\n";
    spacer_ensemble * crosslks; 
    
    if(spacer_pos_vec.size() == 0){
        cout<<"\nDEBUG initializing spacers with spacer density";
        crosslks = new spacer_ensemble( spacer_density, {xrange, yrange}, dt, temperature, 
                spacer_length, net, spacer_v, spacer_stiffness, fene_pct, s_kon, s_kend,
                s_kend, s_stall, s_break, s_bind, viscosity, spacer_position_arrs, bnd_cnd);
    }
    else
        crosslks = new spacer_ensemble( spacer_pos_vec, {xrange, yrange}, dt, temperature, 
                spacer_length, net, spacer_v, spacer_stiffness, fene_pct, s_kon, s_kend,
                s_kend, s_stall, s_break, s_bind, viscosity, bnd_cnd);
    crosslks->set_bending(s_bend, s_th0);
    if (dead_head_flag) crosslks->kill_heads(dead_head);

    // Write the output configuration file
    string output_file                         =   dir + "/data/output.txt";
    o_file.open(output_file.c_str());
    o_file << " FILE: "                 << output_file     <<"\n";
    o_file << " Actin Density: "        << actin_density   << ", Actin Mean Length: "          << actin_length              << "\n";
    o_file << " Passive Motor Density: "        << spacer_density   << ", Passive Motor Rest Length: "          << spacer_length              << ", Passive Motor Stiffness: "       << spacer_stiffness        <<"\n";
    o_file << " Passive Motor unloaded speed: " << spacer_v          << ", Passive Motor binding rate: "         << s_kon                     <<"\n";
    o_file << " Passive Motor unbinding rate: " << s_koff          << ", Passive Motor end detachment rate: "  << s_kend                    <<"\n";
    o_file << " Link Rest Length: "     << link_length     << ", Link Stretching Stiffness: "  << link_stretching_stiffness <<", Link Bending Stiffness: " << link_bending_stiffness <<"\n";
    o_file << " Simulation time: "      << tfinal - tinit  << ", dt: " << dt <<", dt between output files: "<< n_bw_print*dt<<", Viscosity: " << viscosity              <<"\n";
    o_file << " Boundary Conditions: " <<bnd_cnd<<"\n";
    o_file.close();
    
    cout<<"\nUpdating filaments and crosslinks in the network..";
    string time_str; 
    count=0;
    t = 0;
    cout<<"\nDEBUG: #crosslinks = "<<crosslks->get_nmotors();
    while (t < tfinal) {
        
        //print to file
	    if (t+dt/100 >= tinit && (count-unprinted_count)%n_bw_print==0) {
	        
            if (t>tinit) time_str ="\n";
            time_str += "t = "+to_string(t);
            
            file_a << time_str<<"\tN = "<<to_string(net->get_nactins());
            net->write_actins(file_a);
            
            file_l << time_str<<"\tN = "<<to_string(net->get_nlinks());
            net->write_links(file_l);
            
            file_s << time_str<<"\tN = "<<to_string(crosslks->get_nmotors());
            crosslks->motor_write(file_s);
            
            file_th << time_str<<"\tN = "<<to_string(net->get_nlinks());
            net->write_thermo(file_th);

            file_pe << net->get_stretching_energy()<<"\t"<<net->get_bending_energy()<<"\t"<<crosslks->get_potential_energy()<<endl;
		}
        
        if (count%n_bw_stdout==0) {
			cout<<"\nTime counts: "<<count;
		    //net->print_filament_thermo();
            net->print_network_thermo();
            crosslks->print_ensemble_thermo();
        }

        //update network
        net->update();//updates all forces, velocities and positions of filaments

        //update cross linkers
        if (static_cl_flag)
            crosslks->motor_update();
        else
            crosslks->motor_walk(t);
       
        //clear the vector of fractured filaments
        net->clear_broken();

        
        t+=dt;
		count++;

        
    }

    file_a << "\n";
    file_l << "\n";
    file_s << "\n";
    file_th << "\n";

    file_a.close();
    file_l.close();
    file_s.close();
    file_th.close(); 
    file_pe.close(); 
    //Delete all objects created
    cout<<"\nHere's where I think I delete things\n";
    
    delete crosslks;
    delete net;
    
    
    
    cout<<"\nTime counts: "<<count;
	cout<<"\nExecuted";
	cout<<"\n Done\n";
    
    return 0;
}
